from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

# Security Misconfiguration: Debug mode enabled, sensitive data exposed
app.config['DEBUG'] = True

# Sensitive hardcoded secrets
SECRET_KEY = "hardcodedsecret123"
API_KEYS = ["key1", "key2"]  # Simulates improper inventory management

# Root route to provide information
@app.route('/')
def home():
    return "Welcome to the Vulnerable API. Available endpoints: /auth, /data, /admin, /fetch, /consume"

# Endpoint for Broken Authentication
@app.route('/auth', methods=['POST'])
def broken_auth():
    # Insecure authentication mechanism
    username = request.json.get('username')
    password = request.json.get('password')
    if username == "admin" and password == "password":  # Hardcoded credentials
        return jsonify({"status": "success", "token": "admin-token"})
    return jsonify({"status": "failure", "message": "Invalid credentials"}), 401

# Endpoint for Broken Object Level Authorization
@app.route('/data/<int:data_id>', methods=['GET', 'DELETE'])
def broken_object_level_auth(data_id):
    # No authorization check
    fake_database = {1: "Secret Data 1", 2: "Secret Data 2"}
    if request.method == 'GET':
        data = fake_database.get(data_id, "Data not found")
        return jsonify({"status": "success", "data": data})
    elif request.method == 'DELETE':
        if data_id in fake_database:
            del fake_database[data_id]
            return jsonify({"status": "success", "message": "Data deleted"})
        return jsonify({"status": "failure", "message": "Data not found"}), 404

# Endpoint for Improper Inventory Management
@app.route('/admin/api-keys', methods=['GET'])
def improper_inventory_management():
    # Exposes API keys without restrictions
    return jsonify({"status": "success", "api_keys": API_KEYS})

# Endpoint for Server Side Request Forgery (SSRF)
@app.route('/fetch', methods=['POST'])
def fetch_url():
    try:
        target_url = request.json.get('url')
        response = requests.get(target_url)  # No validation on URL
        return jsonify({"status": "success", "response": response.text[:200]})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

# Endpoint for Unrestricted Resource Consumption
@app.route('/consume', methods=['GET'])
def consume_resources():
    try:
        size = int(request.args.get('size', '9999999999'))  # Default to a large size
        large_data = "X" * size
        return jsonify({"status": "success", "data_length": len(large_data)})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

# Unsafe Consumption of APIs
@app.route('/unsafe', methods=['POST'])
def unsafe_api():
    try:
        external_data = request.json  # No validation of input
        return jsonify({"status": "success", "processed_data": external_data})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

if __name__ == "__main__":
    app.run(port=5000)
