from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

# Security Misconfiguration: Debug mode enabled
app.config['DEBUG'] = True

# Root route to provide information
@app.route('/')
def home():
    return "Welcome to the Insecure API. Available endpoints: /consume, /fetch, /unsafe"

# Favicon route to handle browser requests
@app.route('/favicon.ico')
def favicon():
    return '', 204

# Endpoint for Unrestricted Resource Consumption
@app.route('/consume', methods=['GET'])
def consume_resources():
    try:
        size = int(request.args.get('size', '9999999999'))  # Default to a very large size
        large_data = "X" * size  # Generate a large string
        return jsonify({"status": "success", "data_length": len(large_data)})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

# Endpoint for Server Side Request Forgery (SSRF)
@app.route('/fetch', methods=['POST'])
def fetch_url():
    try:
        target_url = request.json.get('url')  # Get the target URL from the request body
        if not target_url:
            return jsonify({"status": "error", "message": "URL is required"}), 400
        response = requests.get(target_url)  # Fetch the URL
        return jsonify({"status": "success", "response": response.text[:200]})  # Return a preview of the response
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

# Endpoint for Unsafe Consumption of APIs
@app.route('/unsafe', methods=['POST'])
def unsafe_api():
    try:
        external_data = request.json  # Directly consume external input without validation
        if not external_data:
            return jsonify({"status": "error", "message": "Input data is required"}), 400
        return jsonify({"status": "success", "processed_data": external_data})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

if __name__ == "__main__":
    app.run(port=5000)
