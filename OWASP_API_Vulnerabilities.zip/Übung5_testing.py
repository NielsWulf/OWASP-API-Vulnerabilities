import requests

BASE_URL = "http://127.0.0.1:5000"

# Test Unrestricted Resource Consumption
def test_consume():
    response = requests.get(f"{BASE_URL}/consume?size=9999999999")
    print("Consume Test:", response.json())

# Test Server Side Request Forgery (SSRF)
def test_fetch():
    response = requests.post(f"{BASE_URL}/fetch", json={"url": "http://example.com"})
    print("Fetch Test:", response.json())

# Test Unsafe Consumption of APIs
def test_unsafe():
    response = requests.post(f"{BASE_URL}/unsafe", json={"data": "Test unsafe data"})
    print("Unsafe Test:", response.json())

if __name__ == "__main__":
    test_consume()
    test_fetch()
    test_unsafe()
