import requests

BASE_URL = "http://127.0.0.1:5000"

# Test Unrestricted Resource Consumption
def test_consume():
    response = requests.get(f"{BASE_URL}/consume?size=1000")
    print("Consume Test:", response.json())

# Test Server Side Request Forgery (SSRF)
def test_fetch():
    response = requests.post(f"{BASE_URL}/fetch", json={"url": "http://example.com"})
    print("Fetch Test:", response.json())

# Test Unsafe Consumption of APIs
def test_unsafe():
    response = requests.post(f"{BASE_URL}/unsafe", json={"data": "Test unsafe data"})
    print("Unsafe Test:", response.json())

# Test Broken Authentication
def test_broken_auth():
    response_success = requests.post(
        f"{BASE_URL}/auth", json={"username": "admin", "password": "password"}
    )
    response_failure = requests.post(
        f"{BASE_URL}/auth", json={"username": "user", "password": "wrongpassword"}
    )
    print("Broken Authentication Test - Success:", response_success.json())
    print("Broken Authentication Test - Failure:", response_failure.json())

# Test Broken Object Level Authorization
def test_broken_object_level_auth():
    response_get = requests.get(f"{BASE_URL}/data/1")
    response_delete = requests.delete(f"{BASE_URL}/data/1")
    print("Broken Object Level Authorization Test - GET:", response_get.json())
    print("Broken Object Level Authorization Test - DELETE:", response_delete.json())

# Test Improper Inventory Management
def test_improper_inventory_management():
    response = requests.get(f"{BASE_URL}/admin/api-keys")
    print("Improper Inventory Management Test:", response.json())

if __name__ == "__main__":
    test_consume()
    test_fetch()
    test_unsafe()
    test_broken_auth()
    test_broken_object_level_auth()
    test_improper_inventory_management()
