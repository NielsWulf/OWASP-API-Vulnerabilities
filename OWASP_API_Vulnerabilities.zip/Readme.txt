# Insecure API Project

Overview
This project provides an intentionally insecure API designed for educational purposes. It demonstrates common vulnerabilities from the OWASP API Top 10, allowing developers to learn about API security flaws and their mitigation.

Vulnerabilities Highlighted
1.Unrestricted Resource Consumption: Allows excessive resource usage without input validation.
2.Server-Side Request Forgery (SSRF): Accepts unvalidated URLs, leading to unauthorized requests.
3.Security Misconfiguration: Debug mode is enabled, exposing sensitive information.
4.Unsafe Consumption of APIs: Processes unvalidated input, potentially introducing security risks.
5.Broken Authentication: Uses insecure hardcoded credentials.
6.Broken Object Level Authorization: Permits unauthorized access or modification of data.
7.Improper Inventory Management: Exposes sensitive API keys via an unprotected endpoint.


Endpoints
/consume: Demonstrates unrestricted resource consumption with a size parameter.
/fetch: Fetches content from a user-supplied URL, demonstrating SSRF.
/unsafe: Processes user input without validation.
/auth: Implements insecure authentication using hardcoded credentials.
/data/<data_id>: Exposes data without authorization checks; allows modification or deletion.
/admin/api-keys: Publicly exposes API keys, simulating improper inventory management.

Requirements
Python 3.8 or later
Flask library
Requests library

### How to Install the Correct Python Version
Ensure you are using Python 3.8 or later. You can check your Python version with:
```bash
python --version

## Installation
1. Clone the repository or extract the provided `.zip` file.
2. Navigate to the project directory in your terminal.
3. Install the required dependencies:
   ```bash
   pip install -r requirements.txt


### Testing


Running the API

1.Start the Flask server by running:

	python Übung5.py

2. The server will start locally on http://127.0.0.1:5000.

Testing the API

To test the API endpoints, a Python script (test_api.py) is included. Follow these steps to run the tests:

Open a new terminal window while the Flask server is running.

Run the test script
	
	python Übung5_testing.py