# Insecure API Project

## Overview
This project demonstrates an intentionally insecure API for educational purposes. The API highlights common vulnerabilities from the OWASP API Top 10, including:
- **Unrestricted Resource Consumption**
- **Server Side Request Forgery (SSRF)**
- **Security Misconfiguration**
- **Unsafe Consumption of APIs**

## Features
The API includes the following endpoints:
1. **`/consume`**: Demonstrates **Unrestricted Resource Consumption**.
2. **`/fetch`**: Demonstrates **Server Side Request Forgery (SSRF)**.
3. **`/unsafe`**: Demonstrates **Unsafe Consumption of APIs**.

Additionally, a testing script (`test_api.py`) is provided to automatically verify the behavior of all endpoints.

## Requirements
- Python 3.8+
- Flask
- Requests library

### How to Install the Correct Python Version
Ensure you are using Python 3.8 or later. You can check your Python version with:
```bash
python --version

## Installation
1. Clone the repository or extract the provided `.zip` file.
2. Navigate to the project directory in your terminal.
3. Install the required dependencies:
   ```bash
   pip install -r requirements.txt


### Testing


Running the API

1.Start the Flask server by running:

	python Übung5.py

2. The server will start locally on http://127.0.0.1:5000.

Testing the API

To test the API endpoints, a Python script (test_api.py) is included. Follow these steps to run the tests:

Open a new terminal window while the Flask server is running.

Run the test script
	
	python Übung5_testing.py